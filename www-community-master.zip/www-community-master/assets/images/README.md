# placeholder

Put images you wish to link to in this folder

link would be in form /assets/images/<filename.ext>
