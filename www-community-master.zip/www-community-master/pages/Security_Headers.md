---

title: Security Headers
layout: col-sidebar
author:
contributors:
tags:
auto-migrated: 1
permalink: /Security_Headers

---

{% include writers.html %}

The [OWASP Secure Headers Project](https://owasp.org/www-project-secure-headers/) provides the technical information, about the HTTP headers, that can be leveraged from a security perspective.

