---

layout: col-sidebar
title: XSRF
author: 
contributors: 
permalink: /attacks/XSRF
tags: attack, XSRF
auto-migrated: 1

---

[Cross-Site Request Forgery (CSRF)](csrf)
