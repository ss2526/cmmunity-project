---

layout: col-sidebar
title: Code Sprint
tags: cs
permalink: /initiatives/code_sprint/

---

# OWASP Code Sprint Information

OWASP has hosted a number of Code Sprint initiatives..

## History

- Code Sprint 2017
  - [Code Sprint 2017](cs2017)
- Winter Code Sprint 2014
  - [Winter Code Sprint 2014](wcs2014)
