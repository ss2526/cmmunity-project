### Important Community Links

* [Community]({{ site.baseurl }}/)
  * [Initiatives]({{ site.baseurl }}/initiatives)
    * Code Sprints (You are here)
    * [Google Summer of Code]({{ site.baseurl }}/initiatives/gsoc)
    * [OWASP Bug Bounty]({{ site.baseurl }}/initiatives/bugbounty)
