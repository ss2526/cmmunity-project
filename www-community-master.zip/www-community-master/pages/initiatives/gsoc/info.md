### Important Community Links

* [Community]({{ site.baseurl }}/)
  * [Initiatives]({{ site.baseurl }}/initiatives/)
    * [Code Sprints]({{ site.baseurl }}/initiatives/code_sprint/)
    * Google Summer of Code (You are here)
    * [Google Season of Docs]({{ site.baseurl }}/initiatives/gsod/)
    * [OWASP Bug Bounty]({{ site.baseurl }}/initiatives/bugbounty)
