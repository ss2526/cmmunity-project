### Important Community Links

* [Community]({{ site.baseurl }}/)
  * [Initiatives]({{ site.baseurl }}/initiatives/)
    * [Code Sprints]({{ site.baseurl }}/initiatives/code_sprint/)
    * [Google Summer of Code]({{ site.baseurl }}/initiatives/gsod/)
    * Google Season of Docs (You are here)
    * [OWASP Bug Bounty]({{ site.baseurl }}/initiatives/bugbounty)
