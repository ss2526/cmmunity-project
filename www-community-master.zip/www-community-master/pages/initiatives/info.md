### Important Community Links
* [Attacks]({{ site.baseurl }}/attacks/)
* [Vulnerabilities]({{ site.baseurl }}/vulnerabilities/)
* [Controls]({{ site.baseurl }}/controls/)

#### [Initiatives]({{ site.baseurl }}/initiatives/)
* [Google Summer of Code]({{ site.baseurl }}/initiatives/gsoc/)
* [Google Season of Docs]({{ site.baseurl }}/initiatives/gsod/)
* [Code Sprint]({{ site.baseurl }}/initiatives/code_sprint/)
* [OWASP Bug Bounty]({{ site.baseurl }}/initiatives/bugbounty)
