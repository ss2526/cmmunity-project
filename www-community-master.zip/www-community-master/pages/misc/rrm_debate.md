---

layout: col-sidebar
title: OWASP Risk Rating Methodology - Debate (Historic)
author: kingthorin
contributors:
permalink: /misc/rrm_debate
tags: risk rating methodology, rrm

---

References to previous debate on the OWASP Risk Rating Methodology (these are just a sample, there's much more on the mailing lists):

- <https://wiki.owasp.org/index.php/OWASP_Risk_Rating_Methodology>
- <https://wiki.owasp.org/index.php/Talk:OWASP_Risk_Rating_Methodology>
- <https://lists.owasp.org/pipermail/owasp-testing/2013-August/002177>
- <https://lists.owasp.org/pipermail/owasp-testing/20170713/thread>
- <https://lists.owasp.org/pipermail/owasp-testing/20170712/002522>
- <https://lists.owasp.org/pipermail/owasp-testing/20170608/002510>
- <https://lists.owasp.org/pipermail/owasp-testing/20170607/thread>
- <https://lists.owasp.org/pipermail/owasp-testing/20170605/thread>
