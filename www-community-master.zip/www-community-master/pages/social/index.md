---

title: OWASP Social Events
layout: col-sidebar
permalink: /social/

---

{{ page.title }}

This serves as a place for the OWASP Community to set up social events, gatherings, talks, or even flash mobs

## Upcoming Events
June 6-7, 2020 starting at 12:00p.m. UTC - [OWASP Chapters All Day](chapters_all_day/)